import 'package:flutter/material.dart';

class TransporteView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Transporte', style: TextStyle(fontSize: 24)),
    );
  }
}
