import 'package:flutter/material.dart';

class GastronomiaView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Gastronomía', style: TextStyle(fontSize: 24)),
    );
  }
}
