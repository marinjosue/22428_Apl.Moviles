import 'package:flutter/material.dart';
import '../maps/map_view.dart';

class RutasView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MapView(); // Muestra el mapa de rutas
  }
}
