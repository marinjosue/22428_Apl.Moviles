class TransportModel{
  final String title;
  final String iconPath;

  TransportModel({
    required this.title,
    required this.iconPath,
  });
}